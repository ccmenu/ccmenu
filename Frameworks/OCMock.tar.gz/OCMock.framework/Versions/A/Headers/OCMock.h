//---------------------------------------------------------------------------------------
//  $Id: OCMock.h 2 2004-08-24 17:00:05Z erik $
//  Copyright (c) 2004 by Mulle Kybernetik. See License file for details.
//---------------------------------------------------------------------------------------

#import "OCMockObject.h"
#import "OCMockRecorder.h"
